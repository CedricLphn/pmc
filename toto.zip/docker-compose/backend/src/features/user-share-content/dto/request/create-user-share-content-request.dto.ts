import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class CreateUserShareContentRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly userId: string;
  @ApiProperty()
  @IsNotEmpty()
  public readonly contentId: string;
  @ApiProperty()
  public readonly description: string;
}
