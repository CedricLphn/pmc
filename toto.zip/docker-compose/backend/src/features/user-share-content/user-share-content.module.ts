import { Module } from '@nestjs/common';
import { CqrsModule } from '@nestjs/cqrs';
import { UserShareContentController } from './user-share-content.controller';
import { UserShareContentEntityRepository } from './db/user-share-content-entity.repository';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Content } from '../../infrastructure/database/model/content.entity';
import { CreateUserShareContentHandler } from './application/command/create-user-share-content.handler';
import { DeleteUserShareContentHandler } from './application/command/delete-user-share-content.handler';

@Module({
  imports: [
    CqrsModule,
    TypeOrmModule.forFeature([Content, UserShareContentEntityRepository]),
  ],
  controllers: [UserShareContentController],
  providers: [
    CreateUserShareContentHandler,
    DeleteUserShareContentHandler,
    UserShareContentEntityRepository,
  ],
})
export class UserShareContentModule {}
