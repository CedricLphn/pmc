import { EntityRepository, Repository } from 'typeorm';
import { UserShareContentRepository } from '../../../domain/user-share-content.repository';
import { UserShareContent } from '../../../infrastructure/database/model/user-share-content.entity';

@EntityRepository(UserShareContent)
export class UserShareContentEntityRepository
  extends Repository<UserShareContent>
  implements UserShareContentRepository
{
  async addUserShareContent(userShareContent: UserShareContent): Promise<void> {
    await this.save(userShareContent);
  }

  async deleteUserShareContent(
    userShareContent: UserShareContent,
  ): Promise<void> {
    await this.delete(userShareContent);
  }

  async deleteUserShareContentByContentId(contentId: string): Promise<void> {
    await this.delete({ content_id: contentId });
  }
}
