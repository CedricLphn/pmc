import { DeleteUserShareContentRequest } from '../../dto/request/delete-user-share-content-request.dto';

export class DeleteUserShareContentCommand {
  public readonly userId: string;
  public readonly contentId: string;

  constructor(userId: string, contentId: string) {
    this.userId = userId;
    this.contentId = contentId;
  }

  public static of(
    deleteUserShareContentRequest: DeleteUserShareContentRequest,
  ): DeleteUserShareContentCommand {
    const { userId, contentId } = deleteUserShareContentRequest;
    return new DeleteUserShareContentCommand(userId, contentId);
  }
}
