import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { UserShareContentEntityRepository } from '../../db/user-share-content-entity.repository';
import { UserShareContentRepository } from '../../../../domain/user-share-content.repository';
import { Connection } from 'typeorm';
import { DeleteUserShareContentCommand } from './delete-user-share-content.command';
import { UserShareContent } from '../../../../infrastructure/database/model/user-share-content.entity';

@CommandHandler(DeleteUserShareContentCommand)
export class DeleteUserShareContentHandler
  implements ICommandHandler<DeleteUserShareContentCommand>
{
  private readonly repository: UserShareContentRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(
      UserShareContentEntityRepository,
    );
  }

  async execute(command: DeleteUserShareContentCommand): Promise<void> {
    const userShareContent = new UserShareContent();
    userShareContent.user_id = command.userId;
    userShareContent.content_id = command.contentId;

    await this.repository.deleteUserShareContent(userShareContent);
  }
}
