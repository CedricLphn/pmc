import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { UserShareContentEntityRepository } from '../../db/user-share-content-entity.repository';
import { UserShareContentRepository } from '../../../../domain/user-share-content.repository';
import { Connection } from 'typeorm';
import { CreateUserShareContentCommand } from './create-user-share-content.command';
import { UserShareContent } from '../../../../infrastructure/database/model/user-share-content.entity';
import { User } from '../../../../infrastructure/database/model/user.entity';
import { Content } from '../../../../infrastructure/database/model/content.entity';
import { Notification } from '../../../../infrastructure/database/model/notification.entity';
import { NotificationType } from '../../../../infrastructure/database/model/enums/notification-type';
import { ContentEntityRepository } from '../../../content/db/content-entity.repository';
import { NotificationEntityRepository } from '../../../notifications/db/notification-entity.repository';
import { NotificationRepository } from '../../../../domain/notification.repository';
import { ContentRepository } from '../../../../domain/content.repository';
import { ContentNotFoundException } from '../../../../shared/exceptions/content-not-found.exception';

@CommandHandler(CreateUserShareContentCommand)
export class CreateUserShareContentHandler
  implements ICommandHandler<CreateUserShareContentCommand>
{
  private readonly userShareContentRepository: UserShareContentRepository;
  private readonly contentRepository: ContentRepository;
  private readonly notificationRepository: NotificationRepository;

  constructor(connection: Connection) {
    this.userShareContentRepository = connection.getCustomRepository(
      UserShareContentEntityRepository,
    );
    this.contentRepository = connection.getCustomRepository(
      ContentEntityRepository,
    );
    this.notificationRepository = connection.getCustomRepository(
      NotificationEntityRepository,
    );
  }

  async execute(command: CreateUserShareContentCommand): Promise<void> {
    const userShareContent = new UserShareContent();
    userShareContent.user_id = command.userId;
    userShareContent.content_id = command.contentId;
    userShareContent.description = command.description;
    await this.userShareContentRepository.addUserShareContent(userShareContent);

    await this.sendNotification(command);
  }

  private async sendNotification(command: CreateUserShareContentCommand) {
    const foundContent = await this.contentRepository.findById(
      command.contentId,
    );

    if (!foundContent) {
      throw new ContentNotFoundException();
    }

    const user = new User();
    user.id = command.userId;

    const content = new Content();
    content.id = command.contentId;

    const notification = new Notification();
    notification.content_linked = content;
    notification.user_recipient = foundContent.creator_id;
    notification.user_linked = user;
    notification.notification_type = NotificationType.SHARE;
    await this.notificationRepository.addNotification(notification);
  }
}
