import { CreateUserShareContentRequest } from '../../dto/request/create-user-share-content-request.dto';

export class CreateUserShareContentCommand {
  public readonly userId: string;
  public readonly contentId: string;
  public readonly description: string;

  constructor(userId: string, contentId: string, description: string) {
    this.userId = userId;
    this.contentId = contentId;
    this.description = description;
  }

  public static of(
    createUserShareContentRequest: CreateUserShareContentRequest,
  ): CreateUserShareContentCommand {
    const { userId, contentId, description } = createUserShareContentRequest;
    return new CreateUserShareContentCommand(userId, contentId, description);
  }
}
