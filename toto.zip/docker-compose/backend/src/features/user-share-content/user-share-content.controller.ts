import {
  Body,
  Controller,
  Delete,
  InternalServerErrorException,
  Post,
} from '@nestjs/common';
import { CommandBus, QueryBus } from '@nestjs/cqrs';
import { ApiTags } from '@nestjs/swagger';
import { CreateUserShareContentCommand } from './application/command/create-user-share-content.command';
import { DeleteUserShareContentCommand } from './application/command/delete-user-share-content.command';
import { CreateUserShareContentRequest } from './dto/request/create-user-share-content-request.dto';
import { DeleteUserShareContentRequest } from './dto/request/delete-user-share-content-request.dto';
import { ContentNotFoundException } from '../../shared/exceptions/content-not-found.exception';

@ApiTags('userShareContent')
@Controller('userShareContent')
export class UserShareContentController {
  private readonly commandBus: CommandBus;
  private readonly queryBus: QueryBus;

  constructor(commandBus: CommandBus, queryBus: QueryBus) {
    this.commandBus = commandBus;
    this.queryBus = queryBus;
  }

  @Post('/create')
  async createUserShareContent(
    @Body() createUserShareContentRequest: CreateUserShareContentRequest,
  ) {
    try {
      await this.commandBus.execute(
        CreateUserShareContentCommand.of(createUserShareContentRequest),
      );
    } catch (error) {
      if (error instanceof ContentNotFoundException) {
        throw new ContentNotFoundException();
      }
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Delete('/delete')
  async deleteUserShareContent(
    @Body() deleteUserShareContentRequest: DeleteUserShareContentRequest,
  ) {
    try {
      await this.commandBus.execute(
        DeleteUserShareContentCommand.of(deleteUserShareContentRequest),
      );
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }
}
