import { ApiProperty } from '@nestjs/swagger';

export class AddMediaRequest {
  @ApiProperty({ default: '3053929c-5527-44ca-b4fb-e5a74148d339' })
  public readonly contentId: string;
  @ApiProperty({
    default:
      'https://images.pexels.com/photos/2468056/pexels-photo-2468056.jpeg',
  })
  public readonly url: string;
}
