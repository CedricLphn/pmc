import { Media } from 'src/infrastructure/database/model/media.entity';
import { EntityRepository, Repository } from 'typeorm';
import { MediaRepository } from '../domain/media.repository';

@EntityRepository(Media)
export class MediaEntityRepository
  extends Repository<Media>
  implements MediaRepository
{
  async add(media: Media): Promise<void> {
    await this.save(media);
  }
  async findByContentId(id: string): Promise<Media[]> {
    return this.find({ where: { content: { id } } });
  }
}
