import { Module } from '@nestjs/common';
import { CqrsModule } from '@nestjs/cqrs';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Media } from 'src/infrastructure/database/model/media.entity';
import { AddMediaHandler } from './application/commands/add-media.handler';
import { MediaEntityRepository } from './db/media-entity.repository';
import { MediaController } from './media.controller';

@Module({
  imports: [
    CqrsModule,
    TypeOrmModule.forFeature([Media, MediaEntityRepository]),
  ],
  controllers: [MediaController],
  providers: [MediaEntityRepository, AddMediaHandler],
})
export class MediaModule {}
