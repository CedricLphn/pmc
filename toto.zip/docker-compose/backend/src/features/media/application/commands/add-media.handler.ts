import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { ContentRepository } from 'src/domain/content.repository';
import { ContentEntityRepository } from 'src/features/content/db/content-entity.repository';
import { Media } from 'src/infrastructure/database/model/media.entity';
import { Connection } from 'typeorm';
import { MediaEntityRepository } from '../../db/media-entity.repository';
import { MediaRepository } from '../../domain/media.repository';
import { AddMediaCommand } from './add-media.command';

@CommandHandler(AddMediaCommand)
export class AddMediaHandler implements ICommandHandler<AddMediaCommand> {
  private readonly mediaRepository: MediaRepository;
  private readonly contentRepository: ContentRepository;

  constructor(connection: Connection) {
    this.mediaRepository = connection.getCustomRepository(
      MediaEntityRepository,
    );
    this.contentRepository = connection.getCustomRepository(
      ContentEntityRepository,
    );
  }
  async execute(command: AddMediaCommand) {
    const media = new Media();
    const content = await this.contentRepository.findById(command.contentId);
    media.mediaPath = command.url;
    media.content = content;
    await this.mediaRepository.add(media);
  }
}
