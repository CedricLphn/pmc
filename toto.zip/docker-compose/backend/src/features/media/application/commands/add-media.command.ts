import { AddMediaRequest } from '../../dto/request/add-media-request.dto';

export class AddMediaCommand {
  public readonly url: string;
  public readonly contentId: string;
  constructor(url: string, contentId: string) {
    this.url = url;
    this.contentId = contentId;
  }
  public static of(addMediaRequest: AddMediaRequest): AddMediaCommand {
    const { url, contentId } = addMediaRequest;
    return new AddMediaCommand(url, contentId);
  }
}
