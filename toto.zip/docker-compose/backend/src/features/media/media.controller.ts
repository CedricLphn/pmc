import {
  Body,
  Controller,
  InternalServerErrorException,
  Post,
} from '@nestjs/common';
import { CommandBus, QueryBus } from '@nestjs/cqrs';
import { ApiTags } from '@nestjs/swagger';
import { AddMediaCommand } from './application/commands/add-media.command';
import { AddMediaRequest } from './dto/request/add-media-request.dto';

@ApiTags('Media')
@Controller('media')
export class MediaController {
  private readonly commandBus: CommandBus;
  private readonly queryBus: QueryBus;
  constructor(commandBus: CommandBus, queryBus: QueryBus) {
    this.commandBus = commandBus;
    this.queryBus = queryBus;
  }

  @Post('/add')
  async addMedia(@Body() addMediaRequest: AddMediaRequest) {
    try {
      await this.commandBus.execute(AddMediaCommand.of(addMediaRequest));
    } catch (error) {
      throw new InternalServerErrorException();
    }
  }
}
