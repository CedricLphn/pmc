import { Media } from 'src/infrastructure/database/model/media.entity';

export interface MediaRepository {
  findByContentId(id: string): Promise<Media[]>;
  add(media: Media): Promise<void>;
}
