import { Module } from '@nestjs/common';
import { CqrsModule } from '@nestjs/cqrs';
import { GroupMemberController } from './group-member.controller';
import { GroupMemberEntityRepository } from './db/group-member-entity.repository';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Group } from '../../infrastructure/database/model/group.entity';
import { CreateGroupMemberHandler } from './application/commands/create-group-member.handler';
import { UpdateGroupMemberHandler } from './application/commands/update-group-member.handler';
import { DeleteGroupMemberHandler } from './application/commands/delete-group-member.handler';
import { GetGroupMemberByMemberIdHandler } from './application/query/get-group-member-by-member-id.handler';
import { GetGroupMemberByGroupIdHandler } from './application/query/get-group-member-by-group-id.handler';

@Module({
  imports: [
    CqrsModule,
    TypeOrmModule.forFeature([Group, GroupMemberEntityRepository]),
  ],
  controllers: [GroupMemberController],
  providers: [
    CreateGroupMemberHandler,
    UpdateGroupMemberHandler,
    DeleteGroupMemberHandler,
    GetGroupMemberByMemberIdHandler,
    GetGroupMemberByGroupIdHandler,
    GroupMemberEntityRepository,
  ],
})
export class GroupMemberModule {}
