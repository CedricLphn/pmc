import { EntityRepository, Repository } from 'typeorm';
import { GroupMemberRepository } from '../../../domain/group-member.repository';
import { GroupMember } from '../../../infrastructure/database/model/group-member.entity';
import { Group } from '../../../infrastructure/database/model/group.entity';
import {User} from "../../../infrastructure/database/model/user.entity";

@EntityRepository(GroupMember)
export class GroupMemberEntityRepository
  extends Repository<GroupMember>
  implements GroupMemberRepository
{
  async addGroupMember(groupMember: GroupMember): Promise<void> {
    await this.save(groupMember);
  }

  async updateGroupMember(groupMember: GroupMember): Promise<void> {
    await this.update(groupMember.group_member_id, groupMember);
  }

  async deleteGroupMember(member: User, group: Group): Promise<void> {
    await this.delete({
      member: member,
      group: group,
    });
  }

  findByMemberId(memberId: string): Promise<GroupMember[]> {
    return this.find({
      where: [
        {
          member: memberId,
        },
      ],
      relations: ['member', 'group'],
    });
  }

  findByGroupId(groupId: string): Promise<GroupMember[]> {
    return this.find({
      where: [
        {
          group: groupId,
        },
      ],
      relations: ['member', 'group'],
    });
  }

  async deleteGroupMemberByGroup(group: Group): Promise<void> {
    await this.delete({ group: group });
  }

  findByMemberAndGroupId(
    memberId: string,
    groupId: string,
  ): Promise<GroupMember> {
    return this.findOne({
      where: [
        {
          member: memberId,
          group: groupId,
        },
      ],
      relations: ['member', 'group'],
    });
  }
}
