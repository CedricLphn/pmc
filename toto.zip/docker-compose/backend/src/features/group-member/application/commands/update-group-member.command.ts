import { UpdateGroupMemberRequest } from '../../dto/request/update-group-member-request.dto';
import { Status } from '../../../../infrastructure/database/model/enums/status';
import { Role } from '../../../../infrastructure/database/model/enums/role';

export class UpdateGroupMemberCommand {
  public readonly memberId: string;
  public readonly groupId: string;
  public readonly membershipStatus: Status;
  public readonly userRole: Role;

  constructor(
    memberId: string,
    groupId: string,
    membershipStatus: Status,
    userRole: Role,
  ) {
    this.memberId = memberId;
    this.groupId = groupId;
    this.membershipStatus = membershipStatus;
    this.userRole = userRole;
  }

  public static of(
    updateGroupMemberRequest: UpdateGroupMemberRequest,
  ): UpdateGroupMemberCommand {
    const { memberId, groupId, membershipStatus, userRole } =
      updateGroupMemberRequest;
    return new UpdateGroupMemberCommand(
      memberId,
      groupId,
      membershipStatus,
      userRole,
    );
  }
}
