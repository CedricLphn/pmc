import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { GroupMemberEntityRepository } from '../../db/group-member-entity.repository';
import { Connection } from 'typeorm';
import { CreateGroupMemberCommand } from './create-group-member.command';
import { Group } from '../../../../infrastructure/database/model/group.entity';
import { User } from '../../../../infrastructure/database/model/user.entity';
import { GroupMemberRepository } from '../../../../domain/group-member.repository';
import { GroupMember } from '../../../../infrastructure/database/model/group-member.entity';
import { GroupRepository } from '../../../../domain/group.repository';
import { GroupEntityRepository } from '../../../group/db/group-entity.repository';
import { Confidentiality } from '../../../../infrastructure/database/model/enums/confidentiality';
import { Status } from '../../../../infrastructure/database/model/enums/status';
import { GroupNotFoundException } from '../exception/group-not-found.exception';
import { AlreadyMemberException } from '../exception/already-member.exception';
import { CantBeMemberOfOwnGroupException } from '../exception/cant-be-member-of-own-group.exception';
import { NotificationRepository } from '../../../../domain/notification.repository';
import { NotificationEntityRepository } from '../../../notifications/db/notification-entity.repository';
import { Notification } from '../../../../infrastructure/database/model/notification.entity';
import { NotificationType } from '../../../../infrastructure/database/model/enums/notification-type';
import { Role } from '../../../../infrastructure/database/model/enums/role';

@CommandHandler(CreateGroupMemberCommand)
export class CreateGroupMemberHandler
  implements ICommandHandler<CreateGroupMemberCommand>
{
  private readonly groupMemberRepository: GroupMemberRepository;
  private readonly groupRepository: GroupRepository;
  private readonly notificationRepository: NotificationRepository;

  constructor(connection: Connection) {
    this.groupMemberRepository = connection.getCustomRepository(
      GroupMemberEntityRepository,
    );
    this.groupRepository = connection.getCustomRepository(
      GroupEntityRepository,
    );
    this.notificationRepository = connection.getCustomRepository(
      NotificationEntityRepository,
    );
  }

  async execute(command: CreateGroupMemberCommand): Promise<void> {
    const foundGroupMember =
      await this.groupMemberRepository.findByMemberAndGroupId(
        command.memberId,
        command.groupId,
      );
    if (foundGroupMember != null) {
      throw new AlreadyMemberException();
    }

    const foundGroup = await this.groupRepository.findById(command.groupId);
    if (foundGroup == null) {
      throw new GroupNotFoundException();
    }
    if (foundGroup.creator.id === command.memberId) {
      throw new CantBeMemberOfOwnGroupException();
    }

    const member = new User();
    member.id = command.memberId;

    const group = new Group();
    group.id = command.groupId;

    const groupMember = new GroupMember();
    groupMember.member = member;
    groupMember.group = group;
    if (foundGroup.confidentiality === Confidentiality.PUBLIC) {
      groupMember.membership_status = Status.ACCEPTED;
    } else {
      groupMember.membership_status = Status.PENDING_INVIT;
    }

    await this.groupMemberRepository.addGroupMember(groupMember);

    await this.sendNotification(command, foundGroup);
  }

  private async sendNotification(
    command: CreateGroupMemberCommand,
    foundGroup: Group,
  ) {
    const user = new User();
    user.id = command.memberId;

    const notification = new Notification();
    notification.group_linked = foundGroup;
    notification.user_recipient = foundGroup.creator;
    notification.user_linked = user;
    if (foundGroup.confidentiality === Confidentiality.PUBLIC) {
      notification.notification_type = NotificationType.GROUP_ACCEPTED;
    } else {
      notification.notification_type = NotificationType.GROUP_JOIN_DEMAND;
    }
    await this.notificationRepository.addNotification(notification);
  }
}
