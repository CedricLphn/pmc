import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { GroupMemberEntityRepository } from '../../db/group-member-entity.repository';
import { Connection } from 'typeorm';
import { UpdateGroupMemberCommand } from './update-group-member.command';
import { GroupMemberRepository } from '../../../../domain/group-member.repository';
import { GroupMember } from '../../../../infrastructure/database/model/group-member.entity';
import { NotificationRepository } from '../../../../domain/notification.repository';
import { NotificationEntityRepository } from '../../../notifications/db/notification-entity.repository';
import { GroupNotFoundException } from '../exception/group-not-found.exception';
import { GroupEntityRepository } from '../../../group/db/group-entity.repository';
import { GroupRepository } from '../../../../domain/group.repository';
import { GroupMemberNotFoundException } from '../exception/group-member-not-found.exception';
import { User } from '../../../../infrastructure/database/model/user.entity';
import { Notification } from '../../../../infrastructure/database/model/notification.entity';
import { Status } from '../../../../infrastructure/database/model/enums/status';
import { NotificationType } from '../../../../infrastructure/database/model/enums/notification-type';

@CommandHandler(UpdateGroupMemberCommand)
export class UpdateGroupMemberHandler
  implements ICommandHandler<UpdateGroupMemberCommand>
{
  private readonly groupMemberRepository: GroupMemberRepository;
  private readonly notificationRepository: NotificationRepository;
  private readonly groupRepository: GroupRepository;

  constructor(connection: Connection) {
    this.groupMemberRepository = connection.getCustomRepository(
      GroupMemberEntityRepository,
    );
    this.notificationRepository = connection.getCustomRepository(
      NotificationEntityRepository,
    );
    this.groupRepository = connection.getCustomRepository(
      GroupEntityRepository,
    );
  }

  async execute(command: UpdateGroupMemberCommand): Promise<void> {
    const foundGroup = await this.groupRepository.findById(command.groupId);
    if (foundGroup == null) {
      throw new GroupNotFoundException();
    }

    const foundGroupMember =
      await this.groupMemberRepository.findByMemberAndGroupId(
        command.memberId,
        command.groupId,
      );

    if (!foundGroupMember) {
      throw new GroupMemberNotFoundException();
    }

    foundGroupMember.user_role = command.userRole;

    if (foundGroupMember.membership_status != command.membershipStatus) {
      foundGroupMember.membership_status = command.membershipStatus;

      await this.groupMemberRepository.updateGroupMember(foundGroupMember);

      await this.sendNotification(command, foundGroupMember);
    }
  }

  private async sendNotification(
    command: UpdateGroupMemberCommand,
    foundGroupMember: GroupMember,
  ) {
    const member = new User();
    member.id = command.memberId;

    const notification = new Notification();
    notification.user_recipient = member;
    notification.group_linked = foundGroupMember.group;
    if (command.membershipStatus == Status.ACCEPTED) {
      notification.notification_type = NotificationType.GROUP_ACCEPTED;
    } else {
      notification.notification_type = NotificationType.GROUP_REFUSED;
    }
    await this.notificationRepository.addNotification(notification);

    await this.notificationRepository.deleteJoinDemandNotificationByMemberAndGroup(
      member,
      foundGroupMember.group,
    );
  }
}
