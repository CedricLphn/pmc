import { DeleteGroupMemberRequest } from '../../dto/request/delete-group-member-request.dto';

export class DeleteGroupMemberCommand {
  public readonly memberId: string;
  public readonly groupId: string;

  constructor(memberId: string, groupId: string) {
    this.memberId = memberId;
    this.groupId = groupId;
  }

  public static of(
    deleteGroupMemberRequest: DeleteGroupMemberRequest,
  ): DeleteGroupMemberCommand {
    const { memberId, groupId } = deleteGroupMemberRequest;
    return new DeleteGroupMemberCommand(memberId, groupId);
  }
}
