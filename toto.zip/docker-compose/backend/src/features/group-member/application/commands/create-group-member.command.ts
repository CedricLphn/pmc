import { CreateGroupMemberRequest } from '../../dto/request/create-group-member-request.dto';

export class CreateGroupMemberCommand {
  public readonly memberId: string;
  public readonly groupId: string;

  constructor(memberId: string, groupId: string) {
    this.memberId = memberId;
    this.groupId = groupId;
  }

  public static of(
    createPublicationRequest: CreateGroupMemberRequest,
  ): CreateGroupMemberCommand {
    const { memberId, groupId } = createPublicationRequest;
    return new CreateGroupMemberCommand(memberId, groupId);
  }
}
