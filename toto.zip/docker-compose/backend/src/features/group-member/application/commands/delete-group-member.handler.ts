import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { GroupMemberEntityRepository } from '../../db/group-member-entity.repository';
import { Connection } from 'typeorm';
import { DeleteGroupMemberCommand } from './delete-group-member.command';
import { GroupMemberRepository } from '../../../../domain/group-member.repository';
import { User } from '../../../../infrastructure/database/model/user.entity';
import { Group } from '../../../../infrastructure/database/model/group.entity';

@CommandHandler(DeleteGroupMemberCommand)
export class DeleteGroupMemberHandler
  implements ICommandHandler<DeleteGroupMemberCommand>
{
  private readonly groupMemberRepository: GroupMemberRepository;

  constructor(connection: Connection) {
    this.groupMemberRepository = connection.getCustomRepository(
      GroupMemberEntityRepository,
    );
  }

  async execute(command: DeleteGroupMemberCommand): Promise<void> {
    const member = new User();
    member.id = command.memberId;

    const group = new Group();
    group.id = command.groupId;

    await this.groupMemberRepository.deleteGroupMember(member, group);
  }
}
