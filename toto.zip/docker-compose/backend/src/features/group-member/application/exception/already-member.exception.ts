import { HttpException } from '@nestjs/common';
import { ErrorCode } from '../../../../shared/exceptions/error-code.enum';

export class AlreadyMemberException extends HttpException {
  constructor() {
    super('Already member', ErrorCode.CONFLICT);
  }
}
