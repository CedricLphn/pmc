import { HttpException } from '@nestjs/common';
import { ErrorCode } from '../../../../shared/exceptions/error-code.enum';

export class GroupNotFoundException extends HttpException {
  constructor() {
    super('Group not found', ErrorCode.NOT_FOUND);
  }
}
