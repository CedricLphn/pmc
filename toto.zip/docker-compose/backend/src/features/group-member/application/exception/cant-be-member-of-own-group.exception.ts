import { HttpException } from '@nestjs/common';
import { ErrorCode } from '../../../../shared/exceptions/error-code.enum';

export class CantBeMemberOfOwnGroupException extends HttpException {
  constructor() {
    super('Impossible to be a member of your own group', ErrorCode.BAD_REQUEST);
  }
}
