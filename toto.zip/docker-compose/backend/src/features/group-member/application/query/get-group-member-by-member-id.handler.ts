import { IQueryHandler, QueryHandler } from '@nestjs/cqrs';
import { Connection } from 'typeorm';
import { GroupMemberEntityRepository } from '../../db/group-member-entity.repository';
import { GetGroupMemberByMemberIdQuery } from './get-group-member-by-member-id.query';
import { GetGroupMemberByMemberIdResponse } from '../../dto/response/get-group-member-by-member-id-response-dto';
import { GroupMemberRepository } from '../../../../domain/group-member.repository';

@QueryHandler(GetGroupMemberByMemberIdQuery)
export class GetGroupMemberByMemberIdHandler
  implements IQueryHandler<GetGroupMemberByMemberIdQuery>
{
  private readonly repository: GroupMemberRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(
      GroupMemberEntityRepository,
    );
  }

  async execute(
    query: GetGroupMemberByMemberIdQuery,
  ): Promise<GetGroupMemberByMemberIdResponse> {
    const { memberId } = query;

    const groups = await this.repository.findByMemberId(memberId);

    return new GetGroupMemberByMemberIdResponse(groups);
  }
}
