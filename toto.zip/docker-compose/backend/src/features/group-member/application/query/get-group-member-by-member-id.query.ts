import { GetGroupMemberByMemberIdRequest } from '../../dto/request/get-group-member-by-member-id-request.dto';

export class GetGroupMemberByMemberIdQuery {
  public readonly memberId: string;
  constructor(memberId: string) {
    this.memberId = memberId;
  }
  public static of(
    getGroupByIdRequest: GetGroupMemberByMemberIdRequest,
  ): GetGroupMemberByMemberIdQuery {
    const { memberId } = getGroupByIdRequest;
    return new GetGroupMemberByMemberIdQuery(memberId);
  }
}
