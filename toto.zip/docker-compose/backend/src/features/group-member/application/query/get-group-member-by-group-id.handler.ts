import { IQueryHandler, QueryHandler } from '@nestjs/cqrs';
import { Connection } from 'typeorm';
import { GroupMemberEntityRepository } from '../../db/group-member-entity.repository';
import { GroupMemberRepository } from '../../../../domain/group-member.repository';
import { GetGroupMemberByGroupIdQuery } from './get-group-member-by-group-id.query';
import { GetGroupMemberByGroupIdResponse } from '../../dto/response/get-group-member-by-group-id-response-dto';

@QueryHandler(GetGroupMemberByGroupIdQuery)
export class GetGroupMemberByGroupIdHandler
  implements IQueryHandler<GetGroupMemberByGroupIdQuery>
{
  private readonly repository: GroupMemberRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(
      GroupMemberEntityRepository,
    );
  }

  async execute(
    query: GetGroupMemberByGroupIdQuery,
  ): Promise<GetGroupMemberByGroupIdResponse> {
    const { groupId } = query;

    const groups = await this.repository.findByGroupId(groupId);

    return new GetGroupMemberByGroupIdResponse(groups);
  }
}
