import { GetGroupMemberByGroupIdRequest } from '../../dto/request/get-group-member-by-group-id-request.dto';

export class GetGroupMemberByGroupIdQuery {
  public readonly groupId: string;
  constructor(groupId: string) {
    this.groupId = groupId;
  }
  public static of(
    getGroupByIdRequest: GetGroupMemberByGroupIdRequest,
  ): GetGroupMemberByGroupIdQuery {
    const { groupId } = getGroupByIdRequest;
    return new GetGroupMemberByGroupIdQuery(groupId);
  }
}
