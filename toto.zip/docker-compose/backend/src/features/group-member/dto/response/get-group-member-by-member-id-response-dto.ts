import { GroupMember } from '../../../../infrastructure/database/model/group-member.entity';

export class GetGroupMemberByMemberIdResponse {
  constructor(groupMember: GroupMember[]) {
    this.groupMember = groupMember;
  }

  readonly groupMember: GroupMember[];
}
