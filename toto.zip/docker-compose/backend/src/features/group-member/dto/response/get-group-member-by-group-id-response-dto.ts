import { GroupMember } from '../../../../infrastructure/database/model/group-member.entity';

export class GetGroupMemberByGroupIdResponse {
  constructor(groupMember: GroupMember[]) {
    this.groupMember = groupMember;
  }

  readonly groupMember: GroupMember[];
}
