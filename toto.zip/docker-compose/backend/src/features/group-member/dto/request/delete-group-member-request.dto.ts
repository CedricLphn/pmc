import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class DeleteGroupMemberRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly memberId: string;
  @ApiProperty()
  @IsNotEmpty()
  public readonly groupId: string;
}
