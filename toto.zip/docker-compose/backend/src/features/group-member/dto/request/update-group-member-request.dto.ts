import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { Status } from '../../../../infrastructure/database/model/enums/status';
import { Role } from '../../../../infrastructure/database/model/enums/role';

export class UpdateGroupMemberRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly memberId: string;
  @ApiProperty()
  @IsNotEmpty()
  public readonly groupId: string;
  @ApiProperty()
  @IsNotEmpty()
  public readonly membershipStatus: Status;
  @ApiProperty()
  public readonly userRole: Role;
}
