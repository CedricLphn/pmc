import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetGroupMemberByGroupIdRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly groupId: string;
}
