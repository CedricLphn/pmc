import {
  Body,
  Controller,
  Delete,
  Get,
  InternalServerErrorException,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { CommandBus, QueryBus } from '@nestjs/cqrs';
import { ApiTags } from '@nestjs/swagger';
import { CreateGroupMemberRequest } from './dto/request/create-group-member-request.dto';
import { CreateGroupMemberCommand } from './application/commands/create-group-member.command';
import { UpdateGroupMemberRequest } from './dto/request/update-group-member-request.dto';
import { UpdateGroupMemberCommand } from './application/commands/update-group-member.command';
import { DeleteGroupMemberRequest } from './dto/request/delete-group-member-request.dto';
import { DeleteGroupMemberCommand } from './application/commands/delete-group-member.command';
import { GetGroupMemberByMemberIdRequest } from './dto/request/get-group-member-by-member-id-request.dto';
import { GetGroupMemberByMemberIdResponse } from './dto/response/get-group-member-by-member-id-response-dto';
import { GetGroupMemberByMemberIdQuery } from './application/query/get-group-member-by-member-id.query';
import { GroupNotFoundException } from './application/exception/group-not-found.exception';
import { AlreadyMemberException } from './application/exception/already-member.exception';
import { CantBeMemberOfOwnGroupException } from './application/exception/cant-be-member-of-own-group.exception';
import { GetGroupMemberByGroupIdRequest } from './dto/request/get-group-member-by-group-id-request.dto';
import { GetGroupMemberByGroupIdQuery } from './application/query/get-group-member-by-group-id.query';
import { GetGroupMemberByGroupIdResponse } from './dto/response/get-group-member-by-group-id-response-dto';

@ApiTags('groupMember')
@Controller('groupMember')
export class GroupMemberController {
  private readonly commandBus: CommandBus;
  private readonly queryBus: QueryBus;

  constructor(commandBus: CommandBus, queryBus: QueryBus) {
    this.commandBus = commandBus;
    this.queryBus = queryBus;
  }

  @Post('/create')
  async createGroupMember(
    @Body() createGroupMemberRequest: CreateGroupMemberRequest,
  ) {
    try {
      await this.commandBus.execute(
        CreateGroupMemberCommand.of(createGroupMemberRequest),
      );
    } catch (error) {
      if (error instanceof GroupNotFoundException) {
        throw new GroupNotFoundException();
      }
      if (error instanceof CantBeMemberOfOwnGroupException) {
        throw new CantBeMemberOfOwnGroupException();
      }
      if (error instanceof AlreadyMemberException) {
        throw new AlreadyMemberException();
      }
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Put('/update')
  async updateGroupMember(
    @Body() updateGroupMemberRequest: UpdateGroupMemberRequest,
  ) {
    try {
      await this.commandBus.execute(
        UpdateGroupMemberCommand.of(updateGroupMemberRequest),
      );
    } catch (error) {
      if (error instanceof GroupNotFoundException) {
        throw new GroupNotFoundException();
      }
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Delete('/delete')
  async deleteGroupMember(
    @Body() deleteGroupMemberRequest: DeleteGroupMemberRequest,
  ) {
    try {
      await this.commandBus.execute(
        DeleteGroupMemberCommand.of(deleteGroupMemberRequest),
      );
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Get('/getByMemberId')
  async getByMemberId(
    @Query() getGroupMemberByMemberIdRequest: GetGroupMemberByMemberIdRequest,
  ) {
    try {
      return await this.queryBus.execute<
        GetGroupMemberByMemberIdQuery,
        GetGroupMemberByMemberIdResponse
      >(GetGroupMemberByMemberIdQuery.of(getGroupMemberByMemberIdRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Get('/getByGroupId')
  async getByGroupId(
    @Query() getGroupMemberByGroupIdRequest: GetGroupMemberByGroupIdRequest,
  ) {
    try {
      return await this.queryBus.execute<
        GetGroupMemberByGroupIdQuery,
        GetGroupMemberByGroupIdResponse
      >(GetGroupMemberByGroupIdQuery.of(getGroupMemberByGroupIdRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }
}
