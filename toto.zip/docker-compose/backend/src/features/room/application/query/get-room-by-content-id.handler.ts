import { ICommandHandler, QueryHandler } from '@nestjs/cqrs';
import { Connection } from 'typeorm';
import { GetRoomByContentIdQuery } from './get-room-by-content-id.query';
import { RoomRepository } from '../../../../domain/room.repository';
import { RoomEntityRepository } from '../../db/room-entity.repository';
import { GetRoomByContentIdResponse } from '../../dto/response/get-room-by-content-id-response.dto';
import { Content } from '../../../../infrastructure/database/model/content.entity';

@QueryHandler(GetRoomByContentIdQuery)
export class GetRoomByContentIdHandler
  implements ICommandHandler<GetRoomByContentIdQuery>
{
  private readonly roomRepository: RoomRepository;

  constructor(connection: Connection) {
    this.roomRepository = connection.getCustomRepository(RoomEntityRepository);
  }

  async execute(
    query: GetRoomByContentIdQuery,
  ): Promise<GetRoomByContentIdResponse> {
    const { contentId } = query;

    const content = new Content();
    content.id = contentId;

    const users = await this.roomRepository.findByContentId(content);

    return new GetRoomByContentIdResponse(users);
  }
}
