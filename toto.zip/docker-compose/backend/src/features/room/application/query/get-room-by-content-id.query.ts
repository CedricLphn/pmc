export class GetRoomByContentIdQuery {
  public readonly contentId: string;
  constructor(contentId: string) {
    this.contentId = contentId;
  }
  public static of(
    getRoomByContentIdQuery: GetRoomByContentIdQuery,
  ): GetRoomByContentIdQuery {
    const { contentId } = getRoomByContentIdQuery;
    return new GetRoomByContentIdQuery(contentId);
  }
}
