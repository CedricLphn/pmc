import { Module } from '@nestjs/common';
import { CqrsModule } from '@nestjs/cqrs';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Room } from '../../infrastructure/database/model/room.entity';
import { RoomEntityRepository } from './db/room-entity.repository';
import { GetRoomByContentIdHandler } from './application/query/get-room-by-content-id.handler';
import { RoomController } from './room.controller';

@Module({
  imports: [CqrsModule, TypeOrmModule.forFeature([Room, RoomEntityRepository])],
  controllers: [RoomController],
  providers: [GetRoomByContentIdHandler, RoomEntityRepository],
})
export class RoomModule {}
