import { EntityRepository, Repository } from 'typeorm';
import { RoomRepository } from '../../../domain/room.repository';
import { Room } from '../../../infrastructure/database/model/room.entity';
import { Content } from '../../../infrastructure/database/model/content.entity';

@EntityRepository(Room)
export class RoomEntityRepository
  extends Repository<Room>
  implements RoomRepository
{
  async addRoom(room: Room): Promise<void> {
    await this.save(room);
  }

  async deleteRoomByContentId(content: Content): Promise<void> {
    await this.delete({
      content: content,
    });
  }

  async findByContentId(content: Content): Promise<Room> {
    return await this.findOne({
      where: {
        content: content,
      },
      relations: ['program'],
    });
  }
}
