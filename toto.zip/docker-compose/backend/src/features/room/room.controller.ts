import {
  Controller,
  Get,
  InternalServerErrorException,
  Query,
} from '@nestjs/common';
import { CommandBus, QueryBus } from '@nestjs/cqrs';
import { ApiTags } from '@nestjs/swagger';
import { GetRoomByContentIdRequest } from './dto/request/get-room-by-content-id-request.dto';
import { GetRoomByContentIdQuery } from './application/query/get-room-by-content-id.query';
import { GetRoomByContentIdResponse } from './dto/response/get-room-by-content-id-response.dto';

@ApiTags('room')
@Controller('room')
export class RoomController {
  private readonly commandBus: CommandBus;
  private readonly queryBus: QueryBus;

  constructor(commandBus: CommandBus, queryBus: QueryBus) {
    this.commandBus = commandBus;
    this.queryBus = queryBus;
  }

  @Get('/getByContentId')
  async getByContentId(
    @Query() getRoomByContentIdRequest: GetRoomByContentIdRequest,
  ) {
    try {
      return await this.queryBus.execute<
        GetRoomByContentIdQuery,
        GetRoomByContentIdResponse
      >(GetRoomByContentIdQuery.of(getRoomByContentIdRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }
}
