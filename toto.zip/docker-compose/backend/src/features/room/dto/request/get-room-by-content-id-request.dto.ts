import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetRoomByContentIdRequest {
  @IsNotEmpty()
  @ApiProperty()
  public readonly contentId: string;
}
