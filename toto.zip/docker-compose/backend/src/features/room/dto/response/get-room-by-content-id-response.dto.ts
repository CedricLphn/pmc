import { Room } from '../../../../infrastructure/database/model/room.entity';

export class GetRoomByContentIdResponse {
  constructor(room: Room) {
    this.room = room;
  }
  readonly room: Room;
}
