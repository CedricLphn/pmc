export interface JwtPayload {
  readonly userId: string;
}
