export const minPasswordLength = 8;
