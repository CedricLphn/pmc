import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { GroupEntityRepository } from '../../db/group-entity.repository';
import { GroupRepository } from '../../../../domain/group.repository';
import { Connection } from 'typeorm';
import { CreateGroupCommand } from './create-group.command';
import { Group } from '../../../../infrastructure/database/model/group.entity';
import { User } from '../../../../infrastructure/database/model/user.entity';

@CommandHandler(CreateGroupCommand)
export class CreateGroupHandler implements ICommandHandler<CreateGroupCommand> {
  private readonly repository: GroupRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(GroupEntityRepository);
  }

  async execute(command: CreateGroupCommand): Promise<void> {
    const creator = new User();
    creator.id = command.creatorId;

    const group = new Group();
    group.name = command.name;
    group.description = command.description;
    group.confidentiality = command.confidentiality;
    group.creator = creator;
    await this.repository.addGroup(group);
  }
}
