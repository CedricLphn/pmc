import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { GroupEntityRepository } from '../../db/group-entity.repository';
import { GroupRepository } from '../../../../domain/group.repository';
import { Connection } from 'typeorm';
import { UpdateGroupCommand } from './update-group.command';
import { Group } from '../../../../infrastructure/database/model/group.entity';

@CommandHandler(UpdateGroupCommand)
export class UpdateGroupHandler implements ICommandHandler<UpdateGroupCommand> {
  private readonly repository: GroupRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(GroupEntityRepository);
  }

  async execute(command: UpdateGroupCommand): Promise<void> {
    const group = new Group();
    group.id = command.groupId;
    group.name = command.name;
    group.description = command.description;
    group.confidentiality = command.confidentiality;
    group.principal_picture_url = command.principalPictureId;
    await this.repository.updateGroup(group);
  }
}
