import { DeleteGroupRequest } from '../../dto/request/delete-group-request.dto';

export class DeleteGroupCommand {
  public readonly groupId: string;

  constructor(groupId: string) {
    this.groupId = groupId;
  }

  public static of(deleteGroupRequest: DeleteGroupRequest): DeleteGroupCommand {
    const { groupId } = deleteGroupRequest;
    return new DeleteGroupCommand(groupId);
  }
}
