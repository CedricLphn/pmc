import { CreateGroupRequest } from '../../dto/request/create-group-request.dto';
import { Confidentiality } from '../../../../infrastructure/database/model/enums/confidentiality';

export class CreateGroupCommand {
  public readonly name: string;
  public readonly description: string;
  public readonly confidentiality: Confidentiality;
  public readonly creatorId: string;
  //public readonly file: Express.Multer.File;

  constructor(
    name: string,
    description: string,
    confidentiality: Confidentiality,
    principalPictureUrl: string,
    creatorId: string,
    //file: Express.Multer.File,
  ) {
    this.name = name;
    this.description = description;
    this.confidentiality = confidentiality;
    this.creatorId = creatorId;
    //this.file = file;
  }

  public static of(
    createPublicationRequest: CreateGroupRequest,
    //file: Express.Multer.File,
  ): CreateGroupCommand {
    const {
      name,
      description,
      confidentiality,
      principalPictureId,
      creatorId,
    } = createPublicationRequest;
    return new CreateGroupCommand(
      name,
      description,
      confidentiality,
      principalPictureId,
      creatorId,
      //file,
    );
  }
}
