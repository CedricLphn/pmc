import { UpdateGroupRequest } from '../../dto/request/update-group-request.dto';
import { Confidentiality } from '../../../../infrastructure/database/model/enums/confidentiality';

export class UpdateGroupCommand {
  public readonly groupId: string;
  public readonly name: string;
  public readonly description: string;
  public readonly confidentiality: Confidentiality;
  public readonly principalPictureId: string;
  //public readonly file: Express.Multer.File;

  constructor(
    groupId: string,
    name: string,
    description: string,
    confidentiality: Confidentiality,
    principalPictureId: string,
    //file: Express.Multer.File,
  ) {
    this.groupId = groupId;
    this.name = name;
    this.description = description;
    this.confidentiality = confidentiality;
    this.principalPictureId = principalPictureId;
    //this.file = file;
  }

  public static of(
    updateGroupRequest: UpdateGroupRequest,
    //file: Express.Multer.File,
  ): UpdateGroupCommand {
    const { groupId, name, description, confidentiality, principalPictureId } =
      updateGroupRequest;
    return new UpdateGroupCommand(
      groupId,
      name,
      description,
      confidentiality,
      principalPictureId,
      //file,
    );
  }
}
