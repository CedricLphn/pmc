import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { GroupEntityRepository } from '../../db/group-entity.repository';
import { GroupRepository } from '../../../../domain/group.repository';
import { Connection } from 'typeorm';
import { DeleteGroupCommand } from './delete-group.command';
import { ContentEntityRepository } from '../../../content/db/content-entity.repository';
import { UserReactToContentEntityRepository } from '../../../user-react-to-content/db/user-react-to-content-entity.repository';
import { UserShareContentEntityRepository } from '../../../user-share-content/db/user-share-content-entity.repository';
import { NotificationEntityRepository } from '../../../notifications/db/notification-entity.repository';
import { ContentRepository } from '../../../../domain/content.repository';
import { UserReactToContentRepository } from '../../../../domain/user-react-to-content.repository';
import { UserShareContentRepository } from '../../../../domain/user-share-content.repository';
import { NotificationRepository } from '../../../../domain/notification.repository';
import { Group } from '../../../../infrastructure/database/model/group.entity';
import { GroupMemberRepository } from '../../../../domain/group-member.repository';
import { GroupMemberEntityRepository } from '../../../group-member/db/group-member-entity.repository';

@CommandHandler(DeleteGroupCommand)
export class DeleteGroupHandler implements ICommandHandler<DeleteGroupCommand> {
  private readonly groupRepository: GroupRepository;
  private readonly contentRepository: ContentRepository;
  private readonly userReactToContentRepository: UserReactToContentRepository;
  private readonly userShareContentRepository: UserShareContentRepository;
  private readonly notificationRepository: NotificationRepository;
  private readonly groupMemberRepository: GroupMemberRepository;

  constructor(connection: Connection) {
    this.groupRepository = connection.getCustomRepository(
      GroupEntityRepository,
    );
    this.contentRepository = connection.getCustomRepository(
      ContentEntityRepository,
    );
    this.userReactToContentRepository = connection.getCustomRepository(
      UserReactToContentEntityRepository,
    );
    this.userShareContentRepository = connection.getCustomRepository(
      UserShareContentEntityRepository,
    );
    this.notificationRepository = connection.getCustomRepository(
      NotificationEntityRepository,
    );
    this.groupMemberRepository = connection.getCustomRepository(
      GroupMemberEntityRepository,
    );
  }

  async execute(command: DeleteGroupCommand): Promise<void> {
    const publicationsToDelete =
      await this.contentRepository.findPublicationsByGroupId(command.groupId);

    for (const content of publicationsToDelete) {
      await this.userReactToContentRepository.deleteReactionsByContentId(
        content.id,
      );
      await this.userShareContentRepository.deleteUserShareContentByContentId(
        content.id,
      );
      await this.notificationRepository.deleteNotificationByContent(content);
      await this.contentRepository.deleteResponsesByContentId(content);
      await this.contentRepository.deleteContent(content.id);
    }
    const group = new Group();
    group.id = command.groupId;
    await this.groupMemberRepository.deleteGroupMemberByGroup(group);
    await this.notificationRepository.deleteNotificationByGroup(group);
    await this.groupRepository.deleteGroup(command.groupId);
  }
}
