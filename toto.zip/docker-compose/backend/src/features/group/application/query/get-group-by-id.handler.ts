import { IQueryHandler, QueryHandler } from '@nestjs/cqrs';
import { Connection } from 'typeorm';
import { GroupEntityRepository } from '../../db/group-entity.repository';
import { GroupRepository } from '../../../../domain/group.repository';
import { GetGroupByIdQuery } from './get-group-by-id.query';
import { GetGroupByIdResponse } from '../../dto/response/get-group-by-id-response-dto';

@QueryHandler(GetGroupByIdQuery)
export class GetGroupByIdHandler implements IQueryHandler<GetGroupByIdQuery> {
  private readonly repository: GroupRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(GroupEntityRepository);
  }

  async execute(query: GetGroupByIdQuery): Promise<GetGroupByIdResponse> {
    const { groupId } = query;

    const groups = await this.repository.findById(groupId);

    return new GetGroupByIdResponse(groups);
  }
}
