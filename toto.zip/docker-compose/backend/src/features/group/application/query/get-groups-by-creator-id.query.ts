import { GetGroupsByCreatorIdRequest } from '../../dto/request/get-groups-by-creator-id-request.dto';

export class GetGroupsByCreatorIdQuery {
  public readonly creatorId: string;
  constructor(creatorId: string) {
    this.creatorId = creatorId;
  }
  public static of(
    getGroupByIdRequest: GetGroupsByCreatorIdRequest,
  ): GetGroupsByCreatorIdQuery {
    const { creatorId } = getGroupByIdRequest;
    return new GetGroupsByCreatorIdQuery(creatorId);
  }
}
