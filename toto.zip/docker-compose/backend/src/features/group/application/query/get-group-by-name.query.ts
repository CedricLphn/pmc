import { GetGroupByNameRequest } from '../../dto/request/get-group-by-name-request.dto';

export class GetGroupByNameQuery {
  public readonly name: string;
  constructor(name: string) {
    this.name = name;
  }
  public static of(
    getGroupByNameRequest: GetGroupByNameRequest,
  ): GetGroupByNameQuery {
    const { name } = getGroupByNameRequest;
    return new GetGroupByNameQuery(name);
  }
}
