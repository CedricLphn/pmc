import { IQueryHandler, QueryHandler } from '@nestjs/cqrs';
import { Connection } from 'typeorm';
import { GroupEntityRepository } from '../../db/group-entity.repository';
import { GroupRepository } from '../../../../domain/group.repository';
import { GetGroupsByCreatorIdQuery } from './get-groups-by-creator-id.query';
import { GetGroupsByCreatorIdResponse } from '../../dto/response/get-groups-by-creator-id-response-dto';

@QueryHandler(GetGroupsByCreatorIdQuery)
export class GetGroupsByCreatorIdHandler
  implements IQueryHandler<GetGroupsByCreatorIdQuery>
{
  private readonly repository: GroupRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(GroupEntityRepository);
  }

  async execute(
    query: GetGroupsByCreatorIdQuery,
  ): Promise<GetGroupsByCreatorIdResponse> {
    const { creatorId } = query;

    const groups = await this.repository.findByCreatorId(creatorId);

    return new GetGroupsByCreatorIdResponse(groups);
  }
}
