import { IQueryHandler, QueryHandler } from '@nestjs/cqrs';
import { Connection } from 'typeorm';
import { GroupEntityRepository } from '../../db/group-entity.repository';
import { GroupRepository } from '../../../../domain/group.repository';
import { GetGroupByNameQuery } from './get-group-by-name.query';
import { GetGroupByNameResponse } from '../../dto/response/get-group-by-name-response-dto';

@QueryHandler(GetGroupByNameQuery)
export class GetGroupByNameHandler
  implements IQueryHandler<GetGroupByNameQuery>
{
  private readonly repository: GroupRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(GroupEntityRepository);
  }

  async execute(query: GetGroupByNameQuery): Promise<GetGroupByNameResponse> {
    const { name } = query;

    const groups = await this.repository.findByName(name);

    return new GetGroupByNameResponse(groups);
  }
}
