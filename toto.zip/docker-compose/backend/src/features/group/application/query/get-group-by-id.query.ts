import { GetGroupByIdRequest } from '../../dto/request/get-group-by-id-request.dto';

export class GetGroupByIdQuery {
  public readonly groupId: string;
  constructor(groupId: string) {
    this.groupId = groupId;
  }
  public static of(
    getGroupByIdRequest: GetGroupByIdRequest,
  ): GetGroupByIdQuery {
    const { groupId } = getGroupByIdRequest;
    return new GetGroupByIdQuery(groupId);
  }
}
