import { EntityRepository, Like, Raw, Repository } from 'typeorm';
import { GroupRepository } from '../../../domain/group.repository';
import { Group } from '../../../infrastructure/database/model/group.entity';
import { Content } from '../../../infrastructure/database/model/content.entity';
import { User } from '../../../infrastructure/database/model/user.entity';
import { UserShareContent } from '../../../infrastructure/database/model/user-share-content.entity';
import { ContentType } from '../../../infrastructure/database/model/enums/content-type';

@EntityRepository(Group)
export class GroupEntityRepository
  extends Repository<Group>
  implements GroupRepository
{
  async addGroup(group: Group): Promise<void> {
    await this.save(group);
  }

  async updateGroup(group: Group): Promise<void> {
    await this.update(group.id, group);
  }

  async deleteGroup(groupId: string): Promise<void> {
    await this.delete(groupId);
  }

  findById(groupId: string): Promise<Group> {
    return this.findOne({
      where: [
        {
          id: groupId,
        },
      ],
      relations: ['creator'],
    });
  }

  findByName(groupName: string): Promise<Group[]> {
    return this.find({
      where: {
        name: Raw((alias) => `UPPER(${alias}) LIKE UPPER(:groupName)`, {
          groupName: `%${groupName}%`,
        }),
      },
      relations: ['creator'],
    });
  }

  findByCreatorId(creatorId: string): Promise<Group[]> {
    return this.find({
      where: [
        {
          creator: creatorId,
        },
      ],
      relations: ['creator'],
    });
  }
}
