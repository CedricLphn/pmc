import { Module } from '@nestjs/common';
import { CqrsModule } from '@nestjs/cqrs';
import { GroupController } from './group.controller';
import { GroupEntityRepository } from './db/group-entity.repository';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Group } from '../../infrastructure/database/model/group.entity';
import { CreateGroupHandler } from './application/commands/create-group.handler';
import { UpdateGroupHandler } from './application/commands/update-group.handler';
import { DeleteGroupHandler } from './application/commands/delete-group.handler';
import { GetGroupByIdHandler } from './application/query/get-group-by-id.handler';
import { GetGroupByNameHandler } from './application/query/get-group-by-name.handler';
import { GetGroupsByCreatorIdHandler } from './application/query/get-groups-by-creator-id.handler';

@Module({
  imports: [
    CqrsModule,
    TypeOrmModule.forFeature([Group, GroupEntityRepository]),
  ],
  controllers: [GroupController],
  providers: [
    CreateGroupHandler,
    UpdateGroupHandler,
    DeleteGroupHandler,
    GetGroupByIdHandler,
    GetGroupByNameHandler,
    GetGroupsByCreatorIdHandler,
    GroupEntityRepository,
  ],
})
export class GroupModule {}
