import { Group } from '../../../../infrastructure/database/model/group.entity';

export class GetGroupByNameResponse {
  constructor(groups: Group[]) {
    this.groups = groups;
  }

  readonly groups: Group[];
}
