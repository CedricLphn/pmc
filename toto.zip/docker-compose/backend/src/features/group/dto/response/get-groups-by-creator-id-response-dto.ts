import { Group } from '../../../../infrastructure/database/model/group.entity';

export class GetGroupsByCreatorIdResponse {
  constructor(groups: Group[]) {
    this.groups = groups;
  }

  readonly groups: Group[];
}
