import { Group } from '../../../../infrastructure/database/model/group.entity';

export class GetGroupByIdResponse {
  constructor(group: Group) {
    this.group = group;
  }

  readonly group: Group;
}
