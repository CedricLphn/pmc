import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { Confidentiality } from '../../../../infrastructure/database/model/enums/confidentiality';

export class CreateGroupRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly name: string;
  @ApiProperty()
  public readonly description: string;
  @ApiProperty()
  public readonly confidentiality: Confidentiality;
  @ApiProperty()
  public readonly principalPictureId: string;
  @ApiProperty()
  @IsNotEmpty()
  public readonly creatorId: string;
}
