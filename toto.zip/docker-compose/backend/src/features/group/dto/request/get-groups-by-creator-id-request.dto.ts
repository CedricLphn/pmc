import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetGroupsByCreatorIdRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly creatorId: string;
}
