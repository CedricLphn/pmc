import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { Confidentiality } from '../../../../infrastructure/database/model/enums/confidentiality';

export class UpdateGroupRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly groupId: string;
  @ApiProperty()
  public readonly name: string;
  @ApiProperty()
  public readonly description: string;
  @ApiProperty()
  public readonly confidentiality: Confidentiality;
  @ApiProperty()
  public readonly principalPictureId: string;
}
