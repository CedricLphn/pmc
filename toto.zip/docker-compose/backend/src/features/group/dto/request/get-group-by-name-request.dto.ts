import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetGroupByNameRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly name: string;
}
