import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class DeleteGroupRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly groupId: string;
}
