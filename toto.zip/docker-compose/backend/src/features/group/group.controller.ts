import {
  Body,
  Controller,
  Delete,
  Get,
  InternalServerErrorException,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { CommandBus, QueryBus } from '@nestjs/cqrs';
import { ApiTags } from '@nestjs/swagger';
import { GetGroupByIdQuery } from './application/query/get-group-by-id.query';
import { CreateGroupCommand } from './application/commands/create-group.command';
import { DeleteGroupCommand } from './application/commands/delete-group.command';
import { CreateGroupRequest } from './dto/request/create-group-request.dto';
import { UpdateGroupRequest } from './dto/request/update-group-request.dto';
import { UpdateGroupCommand } from './application/commands/update-group.command';
import { DeleteGroupRequest } from './dto/request/delete-group-request.dto';
import { GetGroupByIdRequest } from './dto/request/get-group-by-id-request.dto';
import { GetGroupByIdResponse } from './dto/response/get-group-by-id-response-dto';
import { GetGroupByNameRequest } from './dto/request/get-group-by-name-request.dto';
import { GetGroupByNameResponse } from './dto/response/get-group-by-name-response-dto';
import { GetGroupByNameQuery } from './application/query/get-group-by-name.query';
import { GetGroupsByCreatorIdRequest } from './dto/request/get-groups-by-creator-id-request.dto';
import { GetGroupsByCreatorIdQuery } from './application/query/get-groups-by-creator-id.query';
import { GetGroupsByCreatorIdResponse } from './dto/response/get-groups-by-creator-id-response-dto';

@ApiTags('group')
@Controller('group')
export class GroupController {
  private readonly commandBus: CommandBus;
  private readonly queryBus: QueryBus;

  constructor(commandBus: CommandBus, queryBus: QueryBus) {
    this.commandBus = commandBus;
    this.queryBus = queryBus;
  }

  @Post('/create')
  async createGroup(@Body() createGroupRequest: CreateGroupRequest) {
    try {
      await this.commandBus.execute(CreateGroupCommand.of(createGroupRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Put('/update')
  async updateGroup(@Body() updateGroupRequest: UpdateGroupRequest) {
    try {
      await this.commandBus.execute(UpdateGroupCommand.of(updateGroupRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Delete('/delete')
  async deleteGroup(@Body() deleteGroupRequest: DeleteGroupRequest) {
    try {
      await this.commandBus.execute(DeleteGroupCommand.of(deleteGroupRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Get('/getById')
  async getGroupById(@Query() getGroupByIdRequest: GetGroupByIdRequest) {
    try {
      return await this.queryBus.execute<
        GetGroupByIdQuery,
        GetGroupByIdResponse
      >(GetGroupByIdQuery.of(getGroupByIdRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Get('/getByName')
  async getByName(@Query() getGroupByNameRequest: GetGroupByNameRequest) {
    try {
      return await this.queryBus.execute<
        GetGroupByNameQuery,
        GetGroupByNameResponse
      >(GetGroupByNameQuery.of(getGroupByNameRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Get('/getByCreatorId')
  async getByCreatorId(
    @Query() getGroupsByCreatorIdRequest: GetGroupsByCreatorIdRequest,
  ) {
    try {
      return await this.queryBus.execute<
        GetGroupsByCreatorIdQuery,
        GetGroupsByCreatorIdResponse
      >(GetGroupsByCreatorIdQuery.of(getGroupsByCreatorIdRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }
}
