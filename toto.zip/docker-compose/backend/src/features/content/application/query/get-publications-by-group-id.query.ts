import { GetPublicationsByGroupIdRequest } from '../../dto/request/get-publications-by-group-id-request.dto';

export class GetPublicationsByGroupIdQuery {
  public readonly groupId: string;
  constructor(groupId: string) {
    this.groupId = groupId;
  }
  public static of(
    getPublicationsByGroupIdRequest: GetPublicationsByGroupIdRequest,
  ): GetPublicationsByGroupIdQuery {
    const { groupId } = getPublicationsByGroupIdRequest;
    return new GetPublicationsByGroupIdQuery(groupId);
  }
}
