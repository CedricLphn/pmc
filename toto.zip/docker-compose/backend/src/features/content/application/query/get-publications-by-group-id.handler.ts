import { IQueryHandler, QueryHandler } from '@nestjs/cqrs';
import { ContentEntityRepository } from '../../db/content-entity.repository';
import { ContentRepository } from '../../../../domain/content.repository';
import { Connection } from 'typeorm';
import { MediaEntityRepository } from '../../../media/db/media-entity.repository';
import { MediaRepository } from '../../../media/domain/media.repository';
import { PubicationResponse } from '../../dto/response/publication-response-dto';
import { GetPublicationsByGroupIdQuery } from './get-publications-by-group-id.query';
import { UserReactToContentRepository } from '../../../../domain/user-react-to-content.repository';
import { UserReactToContentEntityRepository } from '../../../user-react-to-content/db/user-react-to-content-entity.repository';

@QueryHandler(GetPublicationsByGroupIdQuery)
export class GetPublicationsByGroupIdHandler
  implements IQueryHandler<GetPublicationsByGroupIdQuery>
{
  private readonly repository: ContentRepository;
  private readonly mediaRepository: MediaRepository;
  private readonly userReactToContentRepository: UserReactToContentRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(ContentEntityRepository);
    this.mediaRepository = connection.getCustomRepository(
      MediaEntityRepository,
    );
    this.userReactToContentRepository = connection.getCustomRepository(
      UserReactToContentEntityRepository,
    );
  }

  async execute(
    query: GetPublicationsByGroupIdQuery,
  ): Promise<PubicationResponse[]> {
    const { groupId } = query;

    const publications = await this.repository.findPublicationsByGroupId(
      groupId,
    );
    const publicationWithMedia = publications.map(async (publication) => {
      const medias = await this.mediaRepository.findByContentId(publication.id);
      return new PubicationResponse(
        publication.id,
        publication.title,
        publication.content,
        publication.user_description,
        publication.creator_id,
        publication.content_type,
        publication.created_at,
        medias.map((media) => media.mediaPath),
        publication.group_id,
        publication.parent_id,
        publication.principal_picture_url,
        `${publication.firstname} ${publication.lastname}`,
        await this.userReactToContentRepository.countLike(publication.id),
        await this.userReactToContentRepository.countDislike(publication.id),
        await this.repository.countResponseByContentId(publication.id),
        publication.stdin,
        publication.stdout,
      );
    });
    return Promise.all(publicationWithMedia);
  }
}
