import { ApiProperty } from '@nestjs/swagger';

export class GetPublicationsByGroupIdRequest {
  @ApiProperty()
  public readonly groupId: string;
}
