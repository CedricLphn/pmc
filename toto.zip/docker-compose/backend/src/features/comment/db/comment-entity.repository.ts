import { EntityRepository, Repository } from 'typeorm';
import { CommentRepository } from '../../../domain/comment.repository';
import { Comment } from '../../../infrastructure/database/model/comment.entity';

@EntityRepository(Comment)
export class CommentEntityRepository
  extends Repository<Comment>
  implements CommentRepository
{
  async addComment(comment: Comment): Promise<void> {
    await this.save(comment);
  }

  async updateComment(comment: Comment): Promise<void> {
    await this.update(comment.id, comment);
  }

  async deleteComment(commentId: string): Promise<void> {
    await this.delete(commentId);
  }

  findById(commentId: string): Promise<Comment> {
    return this.findOne({
      where: [
        {
          id: commentId,
        },
      ],
      relations: ['creator'],
    });
  }

  findByRoom(roomId: string): Promise<Comment[]> {
    return this.find({
      where: [
        {
          room: roomId,
        },
      ],
      relations: ['room', 'creator'],
    });
  }
}
