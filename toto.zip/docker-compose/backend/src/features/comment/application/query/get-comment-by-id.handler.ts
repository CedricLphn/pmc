import { IQueryHandler, QueryHandler } from '@nestjs/cqrs';
import { Connection } from 'typeorm';
import { CommentRepository } from '../../../../domain/comment.repository';
import { GetCommentByIdQuery } from './get-comment-by-id.query';
import { CommentEntityRepository } from '../../db/comment-entity.repository';
import { GetCommentByIdResponse } from '../../dto/response/get-comment-by-id-response-dto';

@QueryHandler(GetCommentByIdQuery)
export class GetCommentByIdHandler
  implements IQueryHandler<GetCommentByIdQuery>
{
  private readonly repository: CommentRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(CommentEntityRepository);
  }

  async execute(query: GetCommentByIdQuery): Promise<GetCommentByIdResponse> {
    const { commentId } = query;

    const comments = await this.repository.findById(commentId);

    return new GetCommentByIdResponse(comments);
  }
}
