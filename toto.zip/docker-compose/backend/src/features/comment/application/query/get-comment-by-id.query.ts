import { GetCommentByIdRequest } from '../../dto/request/get-comment-by-id-request.dto';

export class GetCommentByIdQuery {
  public readonly commentId: string;
  constructor(commentId: string) {
    this.commentId = commentId;
  }
  public static of(
    getCommentByIdRequest: GetCommentByIdRequest,
  ): GetCommentByIdQuery {
    const { commentId } = getCommentByIdRequest;
    return new GetCommentByIdQuery(commentId);
  }
}
