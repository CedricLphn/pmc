import { IQueryHandler, QueryHandler } from '@nestjs/cqrs';
import { Connection } from 'typeorm';
import { CommentRepository } from '../../../../domain/comment.repository';
import { GetCommentsByRoomQuery } from './get-comments-by-room.query';
import { CommentEntityRepository } from '../../db/comment-entity.repository';
import { GetCommentByRoomResponse } from '../../dto/response/get-comments-by-room-response-dto';

@QueryHandler(GetCommentsByRoomQuery)
export class GetCommentsByRoomHandler
  implements IQueryHandler<GetCommentsByRoomQuery>
{
  private readonly repository: CommentRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(CommentEntityRepository);
  }

  async execute(
    query: GetCommentsByRoomQuery,
  ): Promise<GetCommentByRoomResponse> {
    const { roomId } = query;

    const comments = await this.repository.findByRoom(roomId);

    return new GetCommentByRoomResponse(comments);
  }
}
