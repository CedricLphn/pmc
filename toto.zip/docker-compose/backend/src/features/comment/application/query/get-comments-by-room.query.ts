import { GetCommentByRoomRequest } from '../../dto/request/get-comments-by-room-request.dto';

export class GetCommentsByRoomQuery {
  public readonly roomId: string;
  constructor(roomId: string) {
    this.roomId = roomId;
  }
  public static of(
    getCommentByRoomRequest: GetCommentByRoomRequest,
  ): GetCommentsByRoomQuery {
    const { roomId } = getCommentByRoomRequest;
    return new GetCommentsByRoomQuery(roomId);
  }
}
