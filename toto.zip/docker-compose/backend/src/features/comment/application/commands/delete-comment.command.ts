import { DeleteCommentRequest } from '../../dto/request/delete-comment-request.dto';

export class DeleteCommentCommand {
  public readonly commentId: string;

  constructor(commentId: string) {
    this.commentId = commentId;
  }

  public static of(
    deleteCommentRequest: DeleteCommentRequest,
  ): DeleteCommentCommand {
    const { commentId } = deleteCommentRequest;
    return new DeleteCommentCommand(commentId);
  }
}
