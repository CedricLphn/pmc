import { CreateCommentRequest } from '../../dto/request/create-comment-request.dto';

export class CreateCommentCommand {
  public readonly content: string;
  public readonly codeLinked: string;
  public readonly creatorId: string;
  public readonly roomId: string;

  constructor(
    content: string,
    codeLinked: string,
    creatorId: string,
    roomId: string,
  ) {
    this.content = content;
    this.codeLinked = codeLinked;
    this.creatorId = creatorId;
    this.roomId = roomId;
  }

  public static of(
    createCommentRequest: CreateCommentRequest,
  ): CreateCommentCommand {
    const { content, codeLinked, creatorId, roomId } = createCommentRequest;
    return new CreateCommentCommand(content, codeLinked, creatorId, roomId);
  }
}
