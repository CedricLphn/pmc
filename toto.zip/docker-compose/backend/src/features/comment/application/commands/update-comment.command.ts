import { UpdateCommentRequest } from '../../dto/request/update-comment-request.dto';

export class UpdateCommentCommand {
  public readonly commentId: string;
  public readonly content: string;

  constructor(commentId: string, content: string) {
    this.commentId = commentId;
    this.content = content;
  }

  public static of(
    updateCommentRequest: UpdateCommentRequest,
  ): UpdateCommentCommand {
    const { commentId, content } = updateCommentRequest;
    return new UpdateCommentCommand(commentId, content);
  }
}
