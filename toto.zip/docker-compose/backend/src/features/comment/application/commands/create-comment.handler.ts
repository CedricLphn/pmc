import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { CommentRepository } from '../../../../domain/comment.repository';
import { Connection } from 'typeorm';
import { Comment } from '../../../../infrastructure/database/model/comment.entity';
import { User } from '../../../../infrastructure/database/model/user.entity';
import { CreateCommentCommand } from './create-comment.command';
import { CommentEntityRepository } from '../../db/comment-entity.repository';
import { Room } from '../../../../infrastructure/database/model/room.entity';

@CommandHandler(CreateCommentCommand)
export class CreateCommentHandler
  implements ICommandHandler<CreateCommentCommand>
{
  private readonly repository: CommentRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(CommentEntityRepository);
  }

  async execute(command: CreateCommentCommand): Promise<void> {
    const creator = new User();
    creator.id = command.creatorId;

    const room = new Room();
    room.id = command.roomId;

    const comment = new Comment();
    comment.content = command.content;
    comment.code_linked = command.codeLinked;
    comment.creator = creator;
    comment.room = room;
    await this.repository.addComment(comment);
  }
}
