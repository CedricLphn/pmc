import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { CommentRepository } from '../../../../domain/comment.repository';
import { Connection } from 'typeorm';
import { Comment } from '../../../../infrastructure/database/model/comment.entity';
import { UpdateCommentCommand } from './update-comment.command';
import { CommentEntityRepository } from '../../db/comment-entity.repository';

@CommandHandler(UpdateCommentCommand)
export class UpdateCommentHandler
  implements ICommandHandler<UpdateCommentCommand>
{
  private readonly repository: CommentRepository;

  constructor(connection: Connection) {
    this.repository = connection.getCustomRepository(CommentEntityRepository);
  }

  async execute(command: UpdateCommentCommand): Promise<void> {
    const comment = new Comment();
    comment.id = command.commentId;
    comment.content = command.content;
    await this.repository.updateComment(comment);
  }
}
