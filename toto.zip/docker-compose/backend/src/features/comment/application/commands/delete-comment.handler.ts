import { CommandHandler, ICommandHandler } from '@nestjs/cqrs';
import { CommentRepository } from '../../../../domain/comment.repository';
import { Connection } from 'typeorm';
import { Comment } from '../../../../infrastructure/database/model/comment.entity';
import { DeleteCommentCommand } from './delete-comment.command';
import { CommentEntityRepository } from '../../db/comment-entity.repository';

@CommandHandler(DeleteCommentCommand)
export class DeleteCommentHandler
  implements ICommandHandler<DeleteCommentCommand>
{
  private readonly commentRepository: CommentRepository;

  constructor(connection: Connection) {
    this.commentRepository = connection.getCustomRepository(
      CommentEntityRepository,
    );
  }

  async execute(command: DeleteCommentCommand): Promise<void> {
    const comment = new Comment();
    comment.id = command.commentId;
    await this.commentRepository.deleteComment(command.commentId);
  }
}
