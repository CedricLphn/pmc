import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class CreateCommentRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly content: string;
  @ApiProperty()
  @IsNotEmpty()
  public readonly codeLinked: string;
  @ApiProperty()
  @IsNotEmpty()
  public readonly creatorId: string;
  @ApiProperty()
  @IsNotEmpty()
  public readonly roomId: string;
}
