import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class DeleteCommentRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly commentId: string;
}
