import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class UpdateCommentRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly commentId: string;
  @ApiProperty()
  @IsNotEmpty()
  public readonly content: string;
}
