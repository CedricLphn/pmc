import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetCommentByIdRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly commentId: string;
}
