import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetCommentByRoomRequest {
  @ApiProperty()
  @IsNotEmpty()
  public readonly roomId: string;
}
