import { Comment } from '../../../../infrastructure/database/model/comment.entity';

export class GetCommentByRoomResponse {
  constructor(comments: Comment[]) {
    this.comments = comments;
  }

  readonly comments: Comment[];
}
