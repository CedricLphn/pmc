import { Comment } from '../../../../infrastructure/database/model/comment.entity';

export class GetCommentByIdResponse {
  constructor(comment: Comment) {
    this.comment = comment;
  }

  readonly comment: Comment;
}
