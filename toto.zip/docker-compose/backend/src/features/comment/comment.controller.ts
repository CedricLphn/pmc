import {
  Body,
  Controller,
  Delete,
  Get,
  InternalServerErrorException,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { CommandBus, QueryBus } from '@nestjs/cqrs';
import { ApiTags } from '@nestjs/swagger';
import { CreateCommentCommand } from './application/commands/create-comment.command';
import { UpdateCommentRequest } from './dto/request/update-comment-request.dto';
import { UpdateCommentCommand } from './application/commands/update-comment.command';
import { DeleteCommentRequest } from './dto/request/delete-comment-request.dto';
import { DeleteCommentCommand } from './application/commands/delete-comment.command';
import { GetCommentByIdRequest } from './dto/request/get-comment-by-id-request.dto';
import { GetCommentByIdQuery } from './application/query/get-comment-by-id.query';
import { GetCommentByIdResponse } from './dto/response/get-comment-by-id-response-dto';
import { GetCommentByRoomRequest } from './dto/request/get-comments-by-room-request.dto';
import { GetCommentByRoomResponse } from './dto/response/get-comments-by-room-response-dto';
import { GetCommentsByRoomQuery } from './application/query/get-comments-by-room.query';
import { CreateCommentRequest } from './dto/request/create-comment-request.dto';

@ApiTags('comment')
@Controller('comment')
export class CommentController {
  private readonly commandBus: CommandBus;
  private readonly queryBus: QueryBus;

  constructor(commandBus: CommandBus, queryBus: QueryBus) {
    this.commandBus = commandBus;
    this.queryBus = queryBus;
  }

  @Post('/create')
  async createComment(@Body() createCommentRequest: CreateCommentRequest) {
    try {
      await this.commandBus.execute(
        CreateCommentCommand.of(createCommentRequest),
      );
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Put('/update')
  async updateComment(@Body() updateCommentRequest: UpdateCommentRequest) {
    try {
      await this.commandBus.execute(
        UpdateCommentCommand.of(updateCommentRequest),
      );
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Delete('/delete')
  async deleteComment(@Body() deleteCommentRequest: DeleteCommentRequest) {
    try {
      await this.commandBus.execute(
        DeleteCommentCommand.of(deleteCommentRequest),
      );
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Get('/getById')
  async getCommentById(@Query() getCommentByIdRequest: GetCommentByIdRequest) {
    try {
      return await this.queryBus.execute<
        GetCommentByIdQuery,
        GetCommentByIdResponse
      >(GetCommentByIdQuery.of(getCommentByIdRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }

  @Get('/getByRoom')
  async getByRoom(@Query() getCommentByRoomRequest: GetCommentByRoomRequest) {
    try {
      return await this.queryBus.execute<
        GetCommentsByRoomQuery,
        GetCommentByRoomResponse
      >(GetCommentsByRoomQuery.of(getCommentByRoomRequest));
    } catch (error) {
      console.error(error);
      throw new InternalServerErrorException();
    }
  }
}
