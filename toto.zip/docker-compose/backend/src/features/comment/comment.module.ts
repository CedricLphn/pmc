import { Module } from '@nestjs/common';
import { CqrsModule } from '@nestjs/cqrs';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommentController } from './comment.controller';
import { CommentEntityRepository } from './db/comment-entity.repository';
import { Comment } from '../../infrastructure/database/model/comment.entity';
import { CreateCommentHandler } from './application/commands/create-comment.handler';
import { GetCommentByIdHandler } from './application/query/get-comment-by-id.handler';
import { UpdateCommentHandler } from './application/commands/update-comment.handler';
import { DeleteCommentHandler } from './application/commands/delete-comment.handler';
import { GetCommentsByRoomHandler } from './application/query/get-comments-by-room.handler';

@Module({
  imports: [
    CqrsModule,
    TypeOrmModule.forFeature([Comment, CommentEntityRepository]),
  ],
  controllers: [CommentController],
  providers: [
    CreateCommentHandler,
    UpdateCommentHandler,
    DeleteCommentHandler,
    GetCommentByIdHandler,
    GetCommentsByRoomHandler,
    CommentEntityRepository,
  ],
})
export class CommentModule {}
