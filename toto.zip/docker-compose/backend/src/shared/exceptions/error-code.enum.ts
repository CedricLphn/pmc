export enum ErrorCode {
  CONFLICT = 409,
  NOT_FOUND = 404,
  BAD_REQUEST = 400,
}
