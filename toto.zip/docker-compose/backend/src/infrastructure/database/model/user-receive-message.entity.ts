import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { Message } from './message.entity';
import { User } from './user.entity';

@Entity()
export class UserReceiveMessage {
  @PrimaryColumn()
  @ManyToOne(() => Message)
  @JoinColumn({ name: 'message_id' })
  message_id: string;

  @PrimaryColumn()
  @ManyToOne(() => User)
  @JoinColumn({ name: 'user_id' })
  user_id: string;

  @Column({ default: false })
  is_seen: boolean;
}
