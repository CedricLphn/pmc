import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { User } from './user.entity';
import { Confidentiality } from './enums/confidentiality';

@Entity()
export class Group {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ nullable: false })
  name: string;

  @Column()
  description: string;

  @Column({
    nullable: false,
    type: 'enum',
    enum: Confidentiality,
    default: Confidentiality.PUBLIC,
  })
  confidentiality: Confidentiality;

  @ManyToOne(() => User, (user) => user.id)
  @JoinColumn({ name: 'creator_id' })
  creator: User;

  @Column({ nullable: true })
  principal_picture_url: string;
}
