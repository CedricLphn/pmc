export enum ReactionType {
  LIKE = 'LIKE',
  DISLIKE = 'DISLIKE',
}
