export enum Confidentiality {
  PUBLIC = 'PUBLIC',
  PRIVATE = 'PRIVATE',
}
