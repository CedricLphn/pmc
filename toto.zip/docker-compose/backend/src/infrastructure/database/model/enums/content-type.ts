export enum ContentType {
  PUBLICATION = 'PUBLICATION',
  COMMENT = 'COMMENT',
}
