export enum Role {
  ADMIN = 'ADMIN',
  MEMBER = 'MEMBER',
}
