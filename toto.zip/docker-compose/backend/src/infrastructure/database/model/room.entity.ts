import {
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Content } from './content.entity';
import { Program } from './program.entity';

@Entity()
export class Room {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Content, (content) => content.id)
  @JoinColumn({ name: 'content_id' })
  content: Content;

  @OneToOne(() => Program, (program) => program.id, { cascade: true })
  @JoinColumn({ name: 'program_id' })
  program: Program;
}
