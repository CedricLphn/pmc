import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Media } from './media.entity';
import { User } from './user.entity';
import { Group } from './group.entity';
import { ContentType } from './enums/content-type';
import { Program } from './program.entity';

@Entity()
export class Content {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ nullable: true })
  title: string;

  @Column({ nullable: false })
  content: string;

  @CreateDateColumn({
    nullable: false,
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP',
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    nullable: false,
    type: 'enum',
    enum: ContentType,
    default: ContentType.PUBLICATION,
    name: 'content_type',
  })
  contentType: ContentType;

  @ManyToOne(() => Group, (group) => group.id)
  @JoinColumn({ name: 'group_id' })
  group: Group;

  @ManyToOne(() => Content, (content) => content.id)
  @JoinColumn({ name: 'parent_id' })
  parent: Content;

  @ManyToOne(() => User, (user) => user.id)
  @JoinColumn({ name: 'creator_id' })
  creator: User;

  @OneToMany(() => Media, (media) => media.content)
  medias: Media[];

  @OneToOne(() => Program, (program) => program.id, { cascade: true })
  @JoinColumn({ name: 'program_id' })
  program: Program;
}
