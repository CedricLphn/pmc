import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Content } from './content.entity';

@Entity()
export class Media {
  @PrimaryGeneratedColumn('uuid', { name: 'media_id' })
  mediaId: string;

  @Column({ nullable: false, name: 'media_path' })
  mediaPath: string;

  @ManyToOne(() => Content, (content) => content.medias)
  @JoinColumn({ name: 'content_id' })
  content: Content;
}
