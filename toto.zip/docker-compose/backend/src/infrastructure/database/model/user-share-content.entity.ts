import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { Content } from './content.entity';
import { User } from './user.entity';

@Entity()
export class UserShareContent {
  @PrimaryColumn()
  @ManyToOne(() => Content)
  @JoinColumn({ name: 'content_id' })
  content_id: string;

  @PrimaryColumn()
  @ManyToOne(() => User)
  @JoinColumn({ name: 'user_id' })
  user_id: string;

  @Column()
  description: string;
}
