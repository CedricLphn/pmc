import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  Unique,
} from 'typeorm';
import { Status } from './enums/status';
import { User } from './user.entity';
import { Group } from './group.entity';
import { Role } from './enums/role';

@Entity()
@Unique(['member'])
export class GroupMember {
  @PrimaryGeneratedColumn('uuid')
  group_member_id: string;

  @Column({
    nullable: false,
    type: 'enum',
    enum: Status,
    default: Status.PENDING_INVIT,
  })
  membership_status: Status;

  @Column({
    nullable: false,
    type: 'enum',
    enum: Role,
    default: Role.MEMBER,
  })
  user_role: Role;

  @ManyToOne(() => User, (user) => user.id)
  @JoinColumn({ name: 'member_id' })
  member: User;

  @ManyToOne(() => Group, (group) => group.id)
  @JoinColumn({ name: 'group_id' })
  group: Group;
}
