import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './features/auth/auth.module';
import { environmentConfig } from './config/environment.config';
import { ContentModule } from './features/content/content.module';
import { UserReactToContentModule } from './features/user-react-to-content/user-react-to-content.module';
import { UserShareContentModule } from './features/user-share-content/user-share-content.module';
import { NotificationModule } from './features/notifications/notification.module';
import { GroupModule } from './features/group/group.module';
import { GroupMemberModule } from './features/group-member/group-member.module';
import { FollowModule } from './features/follow/follow.module';
import { UserModule } from './features/user/user.module';
import { MediaModule } from './features/media/media.module';
import { ProgramModule } from './features/program/program.module';
import { CommentModule } from './features/comment/comment.module';
import { RoomModule } from './features/room/room.module';

@Module({
  imports: [
    AuthModule,
    ContentModule,
    UserReactToContentModule,
    UserShareContentModule,
    NotificationModule,
    GroupModule,
    CommentModule,
    RoomModule,
    GroupMemberModule,
    FollowModule,
    UserModule,
    MediaModule,
    ProgramModule,
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: () => ({
        type: 'postgres',
        url: environmentConfig.dbUrl,
        entities: ['dist/**/*.entity{.ts,.js}'],
        autoLoadEntities: true,
        synchronize: true,
        ssl: false
      }),
    }),
  ],
  controllers: [AppController],
})
export class AppModule {}
