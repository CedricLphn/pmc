import { GroupMember } from '../infrastructure/database/model/group-member.entity';
import { Group } from '../infrastructure/database/model/group.entity';
import { User } from '../infrastructure/database/model/user.entity';

export interface GroupMemberRepository {
  addGroupMember(groupMember: GroupMember): Promise<void>;

  updateGroupMember(groupMember: GroupMember): Promise<void>;

  deleteGroupMember(member: User, group: Group): Promise<void>;

  findByMemberId(memberId: string): Promise<GroupMember[]>;

  findByGroupId(groupId: string): Promise<GroupMember[]>;

  deleteGroupMemberByGroup(group: Group): Promise<void>;

  findByMemberAndGroupId(
    memberId: string,
    groupId: string,
  ): Promise<GroupMember>;
}
