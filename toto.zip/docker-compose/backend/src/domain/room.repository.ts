import { Room } from '../infrastructure/database/model/room.entity';
import { Content } from '../infrastructure/database/model/content.entity';

export interface RoomRepository {
  addRoom(room: Room): Promise<void>;
  findByContentId(content: Content): Promise<Room>;
  deleteRoomByContentId(content: Content): Promise<void>;
}
