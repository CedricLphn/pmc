import { Group } from '../infrastructure/database/model/group.entity';

export interface GroupRepository {
  addGroup(group: Group): Promise<void>;

  updateGroup(group: Group): Promise<void>;

  deleteGroup(groupId: string): Promise<void>;

  findById(groupId: string): Promise<Group>;

  findByName(groupName: string): Promise<Group[]>;

  findByCreatorId(creatorId: string): Promise<Group[]>;
}
