import { UserShareContent } from '../infrastructure/database/model/user-share-content.entity';

export interface UserShareContentRepository {
  addUserShareContent(userShareContent: UserShareContent): Promise<void>;

  deleteUserShareContent(userShareContent: UserShareContent): Promise<void>;

  deleteUserShareContentByContentId(contentId: string): Promise<void>;
}
