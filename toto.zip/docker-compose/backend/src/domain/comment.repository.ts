import { Comment } from '../infrastructure/database/model/comment.entity';

export interface CommentRepository {
  addComment(comment: Comment): Promise<void>;

  updateComment(comment: Comment): Promise<void>;

  deleteComment(commentId: string): Promise<void>;

  findById(commentId: string): Promise<Comment>;

  findByRoom(roomId: string): Promise<Comment[]>;
}
