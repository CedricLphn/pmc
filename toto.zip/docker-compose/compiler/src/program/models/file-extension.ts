export enum FileExtension {
  DART = '.dart',
  PYTHON = '.py',
  C = '.c',
}
