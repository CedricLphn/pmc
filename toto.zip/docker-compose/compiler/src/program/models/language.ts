export enum Language {
  DART = 'DART',
  PYTHON = 'PYTHON',
  C = 'C',
}
