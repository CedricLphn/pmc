export class ProgramResponse {
  stdout: string;
}
