export interface CodeExecutorResult {
  getStdin(): string;
  getStdout(): string;
}
