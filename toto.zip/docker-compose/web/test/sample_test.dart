import 'package:flutter_test/flutter_test.dart';

void main() {
  test('test 1 + 1 = 2', () {
    expect(1 + 1, 2);
  });
}
