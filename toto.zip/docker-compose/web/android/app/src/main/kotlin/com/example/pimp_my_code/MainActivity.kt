package com.example.pimp_my_code

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
