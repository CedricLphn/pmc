abstract class Config {
  get baseUrl;
  get browserUrl;
  get liveCodingUrl;
}
