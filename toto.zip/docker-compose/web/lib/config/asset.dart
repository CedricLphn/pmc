class Asset {
  static const logo = 'assets/images/pimp-my-code-logo.png';
  static const zoomedLogo = 'assets/images/pimp-my-code-logo-zoomed.png';
}
